var app = {
    baseUrl: 'http://localhost:8080/api/v1',
    init: function() {
        app.initDatatable('#usuarios');
    },
    initDatatable: function(id) {
        $(id).DataTable({
            ajax: {
                url: app.baseUrl + '/datos',
                dataSrc: function(json) {
                    return json;
                }
            },
            columns: [
                { data: "id" },
                { data: "name" },
                { data: "fecha_log" },
                { data: "horas_log" }
            ]
        });
    }
};

$(document).ready(function() {
    app.init();
});