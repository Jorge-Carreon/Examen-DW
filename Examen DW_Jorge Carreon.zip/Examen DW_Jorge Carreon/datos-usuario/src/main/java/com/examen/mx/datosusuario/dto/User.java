package com.examen.mx.datosusuario.dto;

public class User {
	String id;
	String name;
	String fecha_log;
	String horas_log;

	public User(String id, String name, String fecha_log, String horas_log) {
		super();
		this.id = id;
		this.name = name;
		this.fecha_log = fecha_log;
		this.horas_log = horas_log;
	}

	public User() {
		// TODO Auto-generated constructor stub
	}



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFecha_log() {
		return fecha_log;
	}

	public void setFecha_log(String fecha_log) {
		this.fecha_log = fecha_log;
	}

	public String getHoras_log() {
		return horas_log;
	}

	public void setHoras_log(String horas_log) {
		this.horas_log = horas_log;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", fecha_log=" + fecha_log + ", horas_log=" + horas_log + "]";
	}
}
