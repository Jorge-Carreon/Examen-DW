package com.examen.mx.datosusuario.utils;

import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;

public class GetRuta {
	//Se crea un método el cual obtendrá la ruta absoluta del archivo
	//Recibe como parámetro el nombre del archivo
	//Y el nombre de la carpeta en el que está contenido
	public static String getAbsoluteFilePath(String filename) {
        URL resource = ClassLoader.getSystemClassLoader().getResource(filename);
        if (resource == null) {
            throw new IllegalArgumentException("File: " + filename + " not found.");
        }
        try {
            Path path = Paths.get(resource.toURI());
            return path.toString();
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }
}
