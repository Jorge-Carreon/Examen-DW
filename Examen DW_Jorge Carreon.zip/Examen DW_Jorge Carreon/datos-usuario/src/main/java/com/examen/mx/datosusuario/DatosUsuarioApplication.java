package com.examen.mx.datosusuario;

import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class DatosUsuarioApplication {

	public static void main(String[] args) throws IOException {
		SpringApplication.run(DatosUsuarioApplication.class, args);
	}

}
