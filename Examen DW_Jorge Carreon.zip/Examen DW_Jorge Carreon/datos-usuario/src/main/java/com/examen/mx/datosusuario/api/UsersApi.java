package com.examen.mx.datosusuario.api;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.examen.mx.datosusuario.dto.User;
import com.examen.mx.datosusuario.utils.GetRuta;

@RestController
@RequestMapping(value = "/api/v1/")
@CrossOrigin("*")
public class UsersApi {

	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public User getUsers() {
		//Solo es de prueba
		return new User("1", "Jorge Carreon", "2022-02-08", "42");
	}
	
	@RequestMapping(value = "/datos", method = RequestMethod.GET)
	public static ArrayList leerArchivo() {
		// crea el flujo para leer desde el archivo
		File file = new File(GetRuta.getAbsoluteFilePath("datos/Usuarios.txt"));
		
		ArrayList usuarios= new ArrayList<>();	
		Scanner scanner;
		try {
			//se pasa el flujo al objeto scanner
			scanner = new Scanner(file);
			while (scanner.hasNextLine()) {
				// el objeto scanner lee linea a linea desde el archivo
				String linea = scanner.nextLine();
				Scanner delimitar = new Scanner(linea);
				//se usa una expresión regular
				//que valida que antes o despues de una coma (,) exista cualquier cosa
				//parte la cadena recibida cada vez que encuentre una coma				
				delimitar.useDelimiter("\\s*,\\s*");
				User e= new User();
				e.setId(delimitar.next());
				e.setName(delimitar.next());
				e.setFecha_log(delimitar.next());
				e.setHoras_log(delimitar.next());
				usuarios.add(e);
			}
			//se cierra el objeto scanner
			scanner.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return usuarios;
	}
	
}
