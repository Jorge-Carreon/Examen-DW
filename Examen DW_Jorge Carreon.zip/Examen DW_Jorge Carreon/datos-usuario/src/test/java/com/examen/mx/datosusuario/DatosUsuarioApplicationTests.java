package com.examen.mx.datosusuario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatosUsuarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
